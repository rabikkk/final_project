# Do not remove this folder (settings)

My default IP for cameras:

140.123.112.121

140.123.112.122

140.123.112.123